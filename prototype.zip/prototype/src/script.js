var fgimage=null;
var bgimage=null;
var fgcanvas;
var bgcanvas;

function loadForegroundImage()
{
    var img = document.getElementById("fgfile");
    fgimage = new SimpleImage(img);
    fgcanvas = document.getElementById("d1");
    fgimage.drawTo(fgcanvas);
}

function loadBackgroundImage()
{
    var img = document.getElementById("bgfile");
    bgimage = new SimpleImage(img);
    bgcanvas = document.getElementById("d2");
    bgimage.drawTo(bgcanvas);
}

function createComposite()
{
    var output = new SimpleImage(fgimage.getWidth(),fgimage.getHeight());
    var greenThreshold = 240;
    for (var pixel of fgimage.values())
    {
        var x = pixel.getX();
        var y = pixel.getY();
        if(pixel.getGreen() > greenThreshold)
        {
            var bgpixel = bgimage.getPixel(x,y);
            output.setPixel(x,y,bgpixel);
        }
        else
        {
            output.setPixel(x,y,pixel);
        }
    }
    return output;
}
function doGreenScreen()
{
    if(fgimage == null || ! fgimage.complete())
    {
        alert("Foreground Image not loaded");
    }
    if(bgimage == null || ! bgimage.complete())
    {
        alert("background Image not loaded");
    }
    clearCanvas();
    var finalImage = createComposite();
  finalImage.drawTo(fgcanvas);
}
function clearCanvas()
{
    doClear(fgcanvas);
    doClear(bgcanvas);
}
function doClear(canvas)
{
    var ctx = canvas.getContext("2d")
    ctx.clearRect(0,0,canvas.width,canvas.height);
}